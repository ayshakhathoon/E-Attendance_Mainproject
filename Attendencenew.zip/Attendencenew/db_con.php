<?php

$conn = mysqli_connect("localhost", "root", "", "attendancenew");
// if($conn){
//     echo "Connected";
// }
// else{
//     echo "not connected";
// }
?>