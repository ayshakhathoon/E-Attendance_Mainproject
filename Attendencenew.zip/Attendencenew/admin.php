<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" content="IE=edge">
    <meta http-eqiv="x-UA-Compatible" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Admin dashboard</title>
    <head>
    <body>
    <div class="side-menu">
    <div class="brand-name"></div>
    <h1>ADMIN DASHBOARD</h1>
    <ul>
        <li>REGISTER</li>
        
        <div class="sub-menu-1">
            <ul>
                <li><a href="reg_s.php">STUDENT</a><li>
                <li><a href="reg_t.php">TEACHER</a><li>
                <li><a href="reg_p.php">PARENT</a><li>
                </ul></div>
        <li>ADD</li>
        <li>VIEW</li>
        <li>ATTENDANCE REPORTS</li>
        <li>LOGOUT</li>


        <ul>
</div>
    </body>
    <html>
        

        
