<?php
include "db_con.php";
session_start();
session_unset();
?><html>
<head>
    <title> E-ATTENDANCE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login_bg">
        <nav>
            <div class="logo">E ATTENDANCE</div>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
            
                <li><a href="sign.php">LOGIN</a></li>
                </a></li>
            </ul>
        </nav>
</div>
        

        <div class="about">
            <h1>About</h1>
          <p>The Student Attendance Management System is a will help faculty manage his/her student's attendance records for each class and subject in a certain college. The system stores the related data or information that are needed to generate the class attendance and also those data that are needed to organized the students. 
</p> 
                
</body>        
</div>
    
 </body>
</html>