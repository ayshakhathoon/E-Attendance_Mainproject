<?php
// Define the structure of the table
$days = array('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday');
$periods = array('8:00-9:00', '9:00-10:00', '10:00-11:00', '11:00-12:00', '12:00-1:00', '1:00-2:00', '2:00-3:00', '3:00-4:00');
$subjects = array('Maths', 'English', 'Science', 'History', 'Geography', 'French', 'Music', 'Art');

// Populate the table with data
$table = array();
foreach ($days as $day) {
  $table[$day] = array();
  foreach ($periods as $period) {
    $table[$day][$period] = $subjects[array_rand($subjects)];
  }
}

// Format the output
echo '<table>';
echo '<tr><th>Time/Day</th>';
foreach ($days as $day) {
  echo '<th>'.$day.'</th>';
}
echo '</tr>';
foreach ($periods as $period) {
  echo '<tr><td>'.$period.'</td>';
  foreach ($days as $day) {
    echo '<td>'.$table[$day][$period].'</td>';
  }
  echo '</tr>';
}
echo '</table>';
?>
