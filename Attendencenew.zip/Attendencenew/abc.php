<?php
include 'db_con.php';
if(isset($_POST['register'])){
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
    $class_id = $_POST['class_id'];
    $dob = $_POST['dob'];
    $email=$_POST['email'];
    $gender = $_POST['gender'];
    $addr = $_POST['address'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
        $user_check = "SELECT `type_id` FROM `tbl_usertype` WHERE `type_name` = 'student'";
        $user_check_rslt = mysqli_query($conn,$user_check);
        while($row = mysqli_fetch_array($user_check_rslt)){
            //echo $row['type_id'];
        $type = $row['type_id'];
        $user_reg = "INSERT INTO `tbl_stu`(`fname`, `lname`, `class_id`, `dob`, `gender`, `adress`, `email`, `phone`, `password`) VALUES ('$fname','$lname','$class_id','$dob','$gender','$addr','$email','$phone','$password'
            )";
            $user_reg_query = mysqli_query($conn,$user_reg);
        
        $last_id = mysqli_insert_id($conn);
        if($user_reg_query){
          $reg = "INSERT INTO `tbl_login`(`adn_no`, `password`, `type_id`) VALUES ('$last_id','$password','$type')";
          $reg_query = mysqli_query($conn,$reg);
          // echo $last_id;
            echo'<script> alert ("Account created '.$last_id.'");</script>';
            echo'<script>window.location.href="sign.php";</script>'; 
        }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>Login</title>
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Rubik:400,700"
    />
    <link rel="stylesheet" href="./style.css" />
  </head>
  <body>
  <script>
                function add()
                {
    var pw1 = document.getElementById("pass").value;
    var pw2 = document.getElementById("cpass").value;
    if(pw1 != pw2) {
        document.getElementById('msg1').style.display = "block";
        document.getElementById('msg1').innerHTML = "Password doesnot match";
        return false;
    }
    else{
        document.getElementById('msg1').style.display = "none";
    }
    var a=document.getElementById("ema").value;
    var st=/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/;
    if(a!="" && st.test(a)==false){
        document.getElementById('message').style.display = "block";
        document.getElementById('message').innerHTML = "Invalid Email id";
        return false;
    }
    else{
        document.getElementById('message').style.display = "none";
    }

    var ph = document.getElementById("phn").value;
    var expr = /^[6-9]\d{9}$/;
    if(ph!="" && expr.test(ph)==false){
        document.getElementById('msg2').style.display = "block";
        document.getElementById('msg2').innerHTML = "Invalid Phone number";
        return false;
                }
                else{
        document.getElementById('msg2').style.display = "none";
    }
            }
                </script>
    <!-- partial:index.partial.html -->
    <div class="login-form">
      <form action="" method="post" onsubmit=" return Validate() && Validatename()  && ValidatePhone() && ValidateEmail() && Validatepassword() && Confirmpass()&& add()">
        <h1>student Register</h1>
        <div class="content">
          <div class="input-field">
            <input type="text" name="fname" placeholder="Enter first name"  required pattern="[a-zA-Z]+" title="Name must be alphabets" onkeyup="retrun Validate()"/>
          </div>
          <div class="input-field">
            <input type="text" name="lname" placeholder="Enter last name" required pattern="[a-zA-Z]+" title="Name must be alphabets" onkeyup="return ValidateName()"/>
          </div>
          <div class="input-field">
            <input type="date" name="dob" placeholder="Enter date of birth"  required />
          </div>
          <div class="input-field">
            <input type="text" name="class_id" placeholder="Enter class id"  required/>
          </div>
          <div class="input-field">
            <input type="text" name="gender" placeholder="Enter gender"  required/>
          </div>
          <div class="input-field">
            <input type="text" name="address" placeholder="Enter address"  required onkeyup="return ValidateAddress()"/>
          </div>
          <div class="input-field">
            <input type="text" name="email" placeholder="Enter mail" id="ema" required pattern="/^[\w\+\'\.-]+@[\w\'\.-]+\.[a-zA-Z]{2,}$/" onkeyup="return ValidateEmail()"/>
          </div>
          <span class="msg" id="message"></span>
          <div class="input-field">
            <input type="text" name="phone" placeholder="Enter phone" id="phn" required pattern="^[6-9]\d{9}$" onkeyup="return ValidatePhone()" title="Please enter a valid phone number"/>
          </div>
          <span class="msg" id="msg2"></span>
          <div class="input-field">
            <input type="password" name="password" placeholder="Password" id="pass" onkeyup="return ValidatePassword()"/>
          </div>
          <div class="input-field">
            <input type="password" name="cpassword" placeholder="confirm password" onkeyup="return add()"   id="cpass"/>
          </div>
          <span class="msg" id="msg1"></span>
          <!-- <a href="#" class="link">Forgot Your Password?</a>  -->
        </div>
        <div class="action">
        <button onclick ="location.href='sign.php'">Sign in</button>
          <button type="submit" name="register" >Register</button>
         
        </div>
      </form>
      
    </div>
    <!-- partial -->
    <!-- <script  src="./script.js"></script> -->
    <script type="text/javascript">
function Validate() 
                            {
                            var val = document.getElementById('fname').value;
                            if (!val.match(/^[A-Z].*$/)) 
                            {
                            //   document.getElementById('nameError').innerHTML="Start with a Capital letter & Only alphabets are allowed";
                                    document.getElementById('fname').value = val;
                                    document.getElementById('fname').style.color = "red";
                                      return false;
                                     flag=1;
                            }
                            if(val.length<3||val.length>30){
                            //   document.getElementById('nameError').innerHTML="Between 3 to 10 characters";
                                    document.getElementById('fname').value = val;
    
    
                                document.getElementById('fname').style.color = "red";
                                      return false;
                                      
                            }
                            else{
    
                            
                            //   document.getElementById('nameError').innerHTML=" ";
                              document.getElementById('fname').style.color = "green";
                             return true;
                            }
                          }
                          function Validatename() 
                          {
                            var val = document.getElementById('lastname').value;
                            if (!val.match(/^[A-Z].*$/)) 
                            {
                            //   document.getElementById('nameError').innerHTML="Start with a Capital letter & Only alphabets are allowed";
                                    document.getElementById('lastname').value = val;
                                    document.getElementById('lastname').style.color = "red";
                                      return false;
                                     flag=1;
                            }
                            if(val.length<1||val.length>30){
                            //   document.getElementById('nameError').innerHTML="Between 3 to 10 characters";
                                    document.getElementById('lastname').value = val;
    
    
                                document.getElementById('lastname').style.color = "red";
                                      return false;
                                      
                            }
                            else{
    
                            
                            //   document.getElementById('nameError').innerHTML=" ";
                              document.getElementById('lastname').style.color = "green";
                             return true;
                            }
                          }
                            
                            function ValidateEmail()
                            {
                         
                              var email=document.getElementById('email').value;  
                              var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
                            //var atposition=x.indexOf("@");  
                            //var dotposition=x.lastIndexOf(".");  
                           
                              if(email.length<3||email.length>30){
                                // document.getElementById('emailError').innerHTML="Invalid Email";
                                    document.getElementById('email').value = email;
                                    document.getElementById('email').style.color = "red";
                                   // alert("err");
                                      return false;
                              }
                             if(!email.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)){  
                                // document.getElementById('emailError').innerHTML="Please enter a valid Email";  
                                document.getElementById('email').value = email;
                                    document.getElementById('email').style.color = "red";
                              return false;  
                              }
                              else{
                            //   document.getElementById('emailError').innerHTML=" ";
                              document.getElementById('email').style.color = "green";
                             return true;
    
                              
                            }
                          }
                            
                             function Validatepassword()
                             {
                          
                              var pass=document.getElementById('password').value;
                              //var patt="/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/";
                              //if (pass.length<8)
                               if(!pass.match(/[a-z]/g)){
                                document.getElementById('password').value = pass;
                                // document.getElementById('passwordError').innerHTML="Enter a strong password eg:Aa#23gh56";
                                  document.getElementById('password').style.color="red";
                                  return false;
                                }
                                if(!pass.match(/[A-Z]/g)){
                                  document.getElementById('password').value = pass;
                                //   document.getElementById('passwordError').innerHTML="Include minimum one capital letter";
                                 document.getElementById('password').style.color="red";

                                     return false;
                                }
                                if(!pass.match(/[0-9]/g)){
                                  document.getElementById('password').value = pass;
                                //   document.getElementById('passwordError').innerHTML="Include 1 digit";
                                document.getElementById('password').style.color="red";

                                return false;
                                 }
                              if(!pass.match(/[^a-zA-Z\d]/g)){
                                document.getElementById('password').value = pass;
                                // document.getElementById('passwordError').innerHTML="Include 1 special character";
                              document.getElementById('password').style.color="red";

                              return false;
                                 }
                            if(pass.length < 8){
                              document.getElementById('password').value = pass;
                            //   document.getElementById('passwordError').innerHTML="Minimum 8 characters";
                              document.getElementById('password').style.color="red";

                              return false;
                            }
                              else{
                                document.getElementById('password').value = pass;

                                // document.getElementById('passwordError').innerHTML="";
                                document.getElementById('password').style.color = "green";
                              }
                           
                               
                          }
                          function Confirmpass()
                             {
                          
                              var pass1=document.getElementById('password').value;
                              var pass2=document.getElementById('cpassword').value;
                               if (pass1!=pass2)
                                        {
                                // document.getElementById('cpasswordError').innerHTML="Password doesn't match ";  
                                document.getElementById('cpassword').value = pass2;
                                document.getElementById('cpassword').style.color = "red";
                              return false;  
                              }
                           
                              else{
                            //   document.getElementById('cpasswordError').innerHTML=" ";
                              document.getElementById('cpassword').style.color = "green";
                            return true;
                              
                            }
                          }
                          function ValidatePhone(){
                            var mobile=document.getElementById('mobile').value;
                            if(!mobile.match(/^[6789][0-9]{9}$/)){
                            // document.getElementById('phoneError').innerHTML="Enter a valid phone number";
                            document.getElementById('mobile').style.color="red";
                           return false;
                           }
                          else{
                        //   document.getElementById('phoneError').innerHTML=" ";
                          document.getElementById('mobile').style.color="green";
                          return true;
}
}
                          
function ValidateAddress(){
  var address = document.getElementById('address').value;
                            if (!address.match(/^[a-zA-Z ]*$/)) 
                            {
                            //   document.getElementById('addressError').innerHTML="Start with a Capital letter & Only alphabets are allowed";
                                    document.getElementById('address').value = address;
                                    document.getElementById('address').style.color = "red";
                                      return false;
                                     flag=1;
                            }
                            if(address.length<3||address.length>30){
                            //   document.getElementById('addressError').innerHTML="Between 3 to 10 characters";
                                    document.getElementById('address').value = address;
    
    
                                document.getElementById('address').style.color = "red";
                                      return false;
                                      
                            }
                            else{
    
                            
                            //   document.getElementById('addressError').innerHTML=" ";
                              document.getElementById('address').style.color = "green";
                             return true;
                            }
}
function ValidateStreet(){
  var address = document.getElementById('street').value;
                            if (!address.match(/^[a-zA-Z ]*$/)) 
                            {
                            //   document.getElementById('addressError').innerHTML="Start with a Capital letter & Only alphabets are allowed";
                                    document.getElementById('street').value = address;
                                    document.getElementById('street').style.color = "red";
                                      return false;
                                     flag=1;
                            }
                            if(address.length<3||address.length>30){
                            //   document.getElementById('addressError').innerHTML="Between 3 to 10 characters";
                                    document.getElementById('street').value = address;
    
    
                                document.getElementById('street').style.color = "red";
                                      return false;
                                      
                            }
                            else{
    
                            
                            //   document.getElementById('addressError').innerHTML=" ";
                              document.getElementById('street').style.color = "green";
                             return true;
                            }
}
function ValidateAadhar()
                            {
                              var Aadhar=document.getElementById('Aadhar').value;
                            if(!Aadhar.match(/^[23456789][0-9]{12}$/)){
                            // document.getElementById('AadharError').innerHTML="Enter a valid phone number";
                            document.getElementById('Aadhar').style.color="red";
                           return false;
                           }
                          else{
                        //   document.getElementById('phoneError').innerHTML=" ";
                          document.getElementById('Aadhar').style.color="green";
                          return true;
}
                            }
    
                            function Val()
                            {
                              if(Validate()===false || ValidateEmail()===false || Validatepassword()===false || Confirmpass()===false || ValidatePhone()===false)
                              {
                                return false;
                              }
                            }
                            
                            
  </script>
  </body>
</html>
