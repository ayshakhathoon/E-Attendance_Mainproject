<?php
include "db_con.php";
session_start();
session_unset();
?><html>
<head>
    <title> E-ATTENDANCE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login_bg">
        <nav>
            <div class="logo">E ATTENDANCE</div>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="about.php">ABOUT</a></li>
              
                <li><a href="sign.php">LOGIN</a></li>
                </a></li>
            </ul>
        </nav>
        <section>
        </section>
</body>
        <section class="about">
            
            <h2 id="About"></h2>
            <div>
                
            
        </section>
</section>       
 </body>
</html>