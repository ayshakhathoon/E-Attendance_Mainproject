<?php
include "db_con.php";
include "session.php";
?>
</<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="CSS1.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">E <b>ATTENDANCE</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
			
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="../dashbord/image/user.jpg">
				<h4>WELCOME ADMIN!</h4>
			</div>
			<ul>
				<li>
				
					<a href="reghome.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>Register</span>
					</a>
				</li>
				

            
				<li>
					<a href="addhome.php">
						<i class="fa fa-plus icons"></i>
						<span>Add</span>
					</a>
				</li>
				<li>
					<a href="viewhome.php">
						<i class="fa fa-eye icons" aria-hidden="true"></i>
						<span>View</span>
						
						
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-info-circle" aria-hidden="true"></i>
						<span>Attendence Report</span>
					</a>
				</li>
				<li>
					<a href="createtimetable.php">
						<i class="fa fa-info-circle" aria-hidden="true"></i>
						<span>Timetable</span>
					</a>
				</li>
					
				<li>
					<a href="logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <title>Time Table</title>
    <style>
    body{
      background-image: url(image2.jpg);
      background-size: cover;
      background-attachment: fixed;
    }
    </style>
  </head>
  <body>
  
  <br><br><br>
  <div class="container">
    <div class="jumbotron">
     
      <p class="lead">Enter Data</p>
      <form action="" method="post">
        <div class="form-group">
        <div class="col-12" required />
      
      <?php
$conn=mysqli_connect("localhost","root","","attendancenew");


$sql=mysqli_query($conn,"select * from tbl_class"); 
?>
<label>Class_id</label><br>


<select   name="class_id" id="class_id" onchange="showResult(this.value)" class="form-control" >
<?php
while($row=mysqli_fetch_array($sql))
{

?>
<option value="<?php echo $row[1] ?>"><?php echo $row[1]?></option>

<?php

}
?>
<br>
</div>
<div class="form-group">
          <label for="formGroupExampleInput">subject1</label>
          <input type="text" class="form-control" name="subject1" id="formGroupExampleInput" placeholder="subject1" required>
        </div>
        <div class="form-group">
          <label for="formGroupExampleInput2">Subject2 </label>
          <input type="text" class="form-control" name="subject2" id="formGroupExampleInput2" placeholder="subject2" required>
        </div>
        <div class="form-group">
          <label for="formGroupExampleInput3">subject3</label>
          <input type="text" class="form-control" name="subject3" id="formGroupExampleInpu3" placeholder="subject3" required>
        </div>
        <div class="form-group">
          <label for="formGroupExampleInput4">subject4</label>
          <input type="text" class="form-control" name="subject4" id="formGroupExampleInput4" placeholder="subject4" required>
        </div>
        <div class="form-group">
          <label for="formGroupExampleInput5">subject5</label>
          <input type="text" class="form-control" name="subject5" id="formGroupExampleInput5" placeholder="subject5" required>
        </div>
        
        <input type="submit" name="submit" value="Submit" class="btn btn-primary" />
        
      </form>
    </div>
  </div>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>
<?php
//echo "asdasdasdaasd";
if(isset($_POST['submit']))
{
  include "db_con.php";
 
  $subject1 = $_POST["subject1"];
  $subject2 = $_POST["subject2"];
  $subject3 = $_POST["subject3"];
  $subject4 = $_POST["subject4"];
  $subject5= $_POST["subject5"];
  
  //echo $tname." ".$sname." ".$cname." ".$st." ".$et;
  //echo "asdasdasdaasd";
  $sql = "INSERT INTO tbl_timetable(`subject1`, `subject2`,`subject3`, `subject4`, `subject5`) VALUES ('$subject1', '$subject2','$subject3', '$subject4', '$subject5' )";
  if (mysqli_query($conn, $sql)) {
    echo "<script type='text/javascript'>
    alert('New record created successfully');
    echo'<script>window.location.href='adhome.php';</script>'; 
  </script>" ;
  } 
  else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
}  
?>
