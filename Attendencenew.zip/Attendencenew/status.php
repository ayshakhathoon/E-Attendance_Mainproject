


<?php
include "db_con.php";
include "session.php";

?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="CSS1.css">
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">E <b>ATTENDANCE</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="">
				<h4>WELCOME STUDENT!</h4>
			</div>
			<ul>
				<li>
					<a href="myprofile.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>My Profile</span>
					</a>
				</li>
				<li>
					<a href="#">
						<i class="fa fa-plus icons"></i>
						<span>Attendance</span>
					</a>
				</li>
				<li>
					<a href="addleave.php">
						<i class="fa fa-eye icons" aria-hidden="true"></i>
						<span>Apply Leave</span>
					</a>
				</li>
				<li>
					<a href="status.php">
						<i class="fa fa-info-circle" aria-hidden="true"></i>
						<span>Leave Status</span>
					</a>
				</li>
					
				<li>
					<a href="logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
<!doctype html>
<html lang="en">
  <head>
  	<title>Status</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,300,700' rel='stylesheet' type='text/css'>

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section">Leave Status</h2>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table table-striped">
						<style>
#approve {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        #approve td, #approve th {
        border: 1px solid #ddd;
        padding: 8px;
        }

        /* #builder tr:nth-child(even){background-color: #f2f2f2;} */

        #approve tr:hover {background-color: #ddd;}

        #approve th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: grey;
        color: white;
        }
        </style>
        <body>
		<table id ="approve"  class="content-table">

<tr>
						  <thead>
						    <tr>
								<th data-breakpoints="xs"></th>
			<th>Adn_no</th>
								
            <th>Reason</th>
            <th>Date</th>
           
						      <th>Status</th>
						    </tr>
						  </thead>
						  <tbody>
						    <tr>
								<?php
								include("db_con.php");
								
								$user=$_SESSION['adn_no'];
								?>
								<?php
								$s=1;
								$currentuser= $_SESSION['adn_no'];
								$sq = mysqli_query($conn,"SELECT adn_no FROM `tbl_stud` where adn_no = '$currentuser'");
								$disp = mysqli_fetch_array($sq);
								
								
								$sql=mysqli_query($conn,"SELECT * FROM `tbl_leave` where adn_no= '$currentuser'");
								
								
								   while($display=mysqli_fetch_array($sql))
								   {
									
									echo "<td>".$s++."</td>";
									$sql3=mysqli_query($conn,"SELECT * FROM `tbl_stud` WHERE `adn_no` = ".$display['adn_no']);							
	$display3=mysqli_fetch_array($sql3);
    echo "<td>".$display['adn_no']."</td>";
									
									
									echo "<td>".$display["reason"]."</td>";
									echo "<td>".$display["date"]."</td>";
									//echo $display['status'];
									if($display['leavestatus'] ==1){
									  echo "<td>approved</td>";
									}
									else if($display['leavestatus'] ==0){
									  echo "<td>rejected</td>";
									}
									else if($display['leavestatus'] ==2){
									  echo "<td>pending</td>";
									}
									//echo "<td><a style='color:#090' href='deleteprod.php?prod_id=".$display['prod_id']."'>Active/InActive</a> </td>";
									
									echo "</tr>";
									
								  }
								
								echo "</table>";
								
								?>
						    </tr>
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</section>

	<script src="js/jquery.min.js"></script>
  <script src="js/popper.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>

	</body>
</html>

