<?php
include "db_con.php";
session_start();
session_unset();
?><html>
<head>
    <title> E-ATTENDANCE</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login_bg">
        <nav>
            <div class="logo">E ATTENDANCE</div>
            <ul>
                <li><a href="index.php">HOME</a></li>
                <li><a href="#">ABOUT</a></li>
                <li><a href="#">CONTACT US</a></li>
                <li><a href="sign.php">LOGIN</a></li>
                </a></li>
            </ul>
        </nav>
        <section class="my-4">
  <div class="py-4">
    <h2 id="about">ABOUT</h2>
</div>
<section >
  
<h2>Revenue eServices</h2>
<p>Land Revenue is a department having a great reach in the routine life of citizen - be it payment of statutory taxes and fees, getting certificates for various purposes, tackling emergencies and the like. Integrating all the services in a common platform is the need of the hour especially in the pandemic scenario where citizen are forced to confine in their households for longer periods. The Web application is designed to avail revenue services by enjoying the comfort of home. The main highlight of the application is that it is mobile friendly. Citizen can avail the services by registering in the portal. The history of the remittances are digitally saved in the individual logins for future reference avoiding the burden of keeping hardcopies of the same. By this endeavor, department is planning to move into a completely IT enabled service delivery system targeting maximum benefit to the citizen. One small step for the citizen and one giant leap for the department
</p></section>
<section>
        <section>
        </section>
        <section>
          
</section>       
 </body>
</html>