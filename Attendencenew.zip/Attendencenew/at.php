


<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="CSS1.css">
</head>
<body>
	<input type="checkbox" id="checkbox">
	<header class="header">
		<h2 class="u-name">E <b>ATTENDANCE</b>
			<label for="checkbox">
				<i id="navbtn" class="fa fa-bars" aria-hidden="true"></i>
			</label>
		</h2>
		<i class="fa fa-user" aria-hidden="true"></i>
	</header>
	<div class="body">
		<nav class="side-bar">
			<div class="user-p">
				<img src="">
				<h4>WELCOME TEACHER!</h4>
			</div>
			<ul>
			<li>
					<a href="viewstudents.php">
						<i class="fa fa-eye icons" aria-hidden="true"></i>
						<span>View students</span>
					</a>
</li>
				<li>	
					<a href="viewtprofile.php">
						<i class="fa fa-desktop" aria-hidden="true"></i>
						<span>My Profile</span>
					</a>
				</li>
				<li>
					<a href="takeattendance.php">
						<i class="fa fa-plus icons"></i>
						<span>Take Attendance</span>
					</a>
				</li>
				<li>
					<a href="teaindex.php">
						<i class="fa fa-eye icons" aria-hidden="true"></i>
						<span>Attendance Report</span>
					</a>
				</li>
				<li>
					<a href="request.php">
						<i class="fa fa-info-circle" aria-hidden="true"></i>
						<span>Leave Apprroval</span>
					</a>
				</li>
					
				<li>
					<a href="logout.php">
						<i class="fa fa-power-off" aria-hidden="true"></i>
						<span>Logout</span>
					</a>
				</li>
			</ul>
		</nav>
		<body>
		
		
	


<?php
	include "db_con.php";
	include "session.php";

	// $query = "SELECT tbl_class.class_name
	//     FROM tbl_teacher
	//     INNER JOIN tbl_class ON tbl_class.class_name = tbl_teacher.class_name
	
	//     Where tbl_teacher.t_id = '$_SESSION[adn_no]'";
	//     $rs = $conn->query($query);
	//     $num = $rs->num_rows;
	//     $rrw = $rs->fetch_assoc();


	// session and Term
    //$querey=mysqli_query($conn,"select * from tblsessionterm where isActive ='1'");
    //$rwws=mysqli_fetch_array($querey);
    //$sessionTermId = $rwws['Id'];

    // $date = date("Y-m-d");
    // $qurty=mysqli_query($conn,"select * from tbl_attendance  where class_name = '[class_name]' and date='$date'");
	// $count = mysqli_num_rows($qurty);

	// if($count == 0)//if Record does not exsit, insert the new record
	// // insert the students record into the attendance table on page load
	// $qus=mysqli_query($conn,"select * from tbl_stud  where class_name = '$_SESSION[adn_no]'");
	// while ($ros = $qus->fetch_assoc())
	// {
	// 	$qquery=mysqli_query($conn,"insert into tbl_attendance(adn_no,status,date) 
	// 	value('$ros'$_SESSION[adn_no]','0','$date')");
	// }


	$date = date("Y-m-d");

	// if(!isset($_POST['save'])){
	// 	$stud_query= "SELECT * FROM tbl_stud WHERE class_name=(SELECT class_name from tbl_teacher WHERE t_id=".$_SESSION['adn_no'].")";
	// 	$rs = $conn->query($stud_query);
	// 	$num = $rs->num_rows;
	// 	if($num > 0)
	// 	{
	// 		while ($rows = $rs->fetch_assoc())
	// 		{
	// 			$check_attendance_res= mysqli_query($conn,"SELECT * FROM tbl_attendance WHERE adn_no=".$rows['adn_no']." AND date='$date'");
	// 			if(!$check_attendance_res || mysqli_num_rows($check_attendance_res) <= 0){
	// 				$qquery=mysqli_query($conn,"INSERT INTO tbl_attendance VALUES(null,".$rows['adn_no'].",'".$rows['class_name']."','0','$date')");
	// 				if($qquery){
	// 					echo "<script>console.log('".$conn->insert_id."');</script>";
	// 				}
	// 			}
	// 			else{
	// 				echo "<script>alert('Attendances has been already taken for today !!');</script>";
	// 				break;
	// 			}
	// 		}
	// 	}
	// }

 	if(isset($_POST['save'])){
		
		$student_query_res= mysqli_query($conn,"SELECT * FROM tbl_stud WHERE class_name=(SELECT class_name from tbl_teacher WHERE t_id=".$_SESSION['adn_no'].")");
		if($student_query_res && mysqli_num_rows($student_query_res) > 0)
		{
			$N= mysqli_num_rows($student_query_res);

			for($i = 0; $i < $N; $i++)
			{
				$stud_str= "stud_id".$i; 
				$student_id= isset($_POST[$stud_str]) ? $_POST[$stud_str] : null;

				$class_str= "class_name".$i; 
				$class_name= isset($_POST[$class_str]) ? $_POST[$class_str] : null;

				$check_str= "check".$i; 
				$check= isset($_POST[$check_str]) ? $_POST[$check_str] : null;

				$class_name_txt= $class_name!=null ? $_POST['class_name'] : null;

				$qurty=mysqli_query($conn,"SELECT * from tbl_attendance  where class_name = '$class_name_txt' and date='$date'");
				$count = mysqli_num_rows($qurty);
				if($count > 0){
					$statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>Attendance has been taken for today!</div>";
					echo "<script>alert('Attendances has been already taken for today !!');</script>";
				}
				else
				{
					$check_val= $check!=null ? '1' : '0';
					$insert_attendance_res= mysqli_query($conn,"INSERT INTO tbl_attendance VALUES(null,".$rows['adn_no'].",'".$rows['class_name']."','$check_val','$date')");
					if ($insert_attendance_res && mysqli_affected_rows($conn) > 0) {
						$statusMsg = "<div class='alert alert-success'  style='margin-right:700px;'>Attendance Taken Successfully!</div>";
						echo "<script>alert('Attendances taken successfully....');</script>";
					}
					else
					{
						$statusMsg = "<div class='alert alert-danger' style='margin-right:700px;'>An error Occurred!</div>";
						echo "<script>alert('Attendances not successful !!');</script>";
					}	
				}
			}
		}
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
<div class="row">
            <div class="col-lg-12">
              <!-- Form Basic -->


              <!-- Input Group -->
        <form method="post" action="at.php">
            <div class="row">
              <div class="col-lg-12">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-primary">
                  <h6 class="m-0 font-weight-bold text-danger">Note: <i>Click on the checkboxes besides each student to take attendance!</i></h6>
                </div>
                <div class="table-responsive p-3">
           
                  <table class="table align-items-center table-flush table-hover">
				  <style>
#approve {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        #approve td, #approve th {
        border: 1px solid #ddd;
        padding: 4px;
        }

        /* #builder tr:nth-child(even){background-color: #f2f2f2;} */

        #approve tr:hover {background-color: #ddd;}

        #approve th {
            padding-right: 12px;
        padding-top: 4px;
        padding-bottom: 4px;
        text-align: left;
        background-color: grey;
        color: white;
        }
        </style>
        <body>
		<table id ="approve"  class="content-table">

<tr>
                    <thead class="thead-light">
                      <tr>
                        <th>#</th>
                        <th>First Name</th>
                        <th>Last Name</th>
    
                        <th>Admission No</th>
                        <th>Class_name</th>
                       
                        <th>Check</th>
                      </tr>
                    </thead>
                    <tbody>

<?php
    // $query = "SELECT tbl_stud.adn_no,tbl_class.class_name As class_name,tbl_stud.fname, tbl_stud.lname FROM tbl_stud INNER JOIN tbl_class ON tbl_class.class_name = tbl_stud.class_name WHERE tbl_stud.adn_no = '".$_SESSION["adn_no"]."'";
	$stud_query= "SELECT * FROM tbl_stud WHERE class_name=(SELECT class_name from tbl_teacher WHERE t_id=".$_SESSION['adn_no'].")";
	$rs = $conn->query($stud_query);
    $num = $rs->num_rows;
    $sn=0;
    $status="";
    if($num > 0)
    {
      while ($rows = $rs->fetch_assoc())
        {
           	$sn = $sn + 1;
          	echo"
            <tr>
              <td>".$sn."</td>
              <td>".$rows['fname']."</td>
              <td>".$rows['lname']."</td>
              <td>".$rows['adn_no']."</td>
              <td>".$rows['class_name']."</td>
              <td><input name='check$sn' type='checkbox' class='form-control'></td>
            </tr>";
            echo "<input name='stud_id$sn' value=".$rows['adn_no']." type='hidden' class='form-control'><input name='class_name$sn' value=".$rows['class_name']." type='hidden' class='form-control'>";
        }
    }
    else
    {
         echo   
         "<div class='alert alert-danger' role='alert'>
          No Record Found!
          </div>";
    }
    
    ?>
  </tbody>
</table>
<br>
<button type="submit" name="save" class="btn btn-primary">Take Attendance</button>
</form>
</div>
</div>
</div>
</div>
</div>
  </body>
  </html>

